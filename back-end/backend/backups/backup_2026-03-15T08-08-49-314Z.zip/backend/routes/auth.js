const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { pool } = require('../config/db');
const { verifyToken } = require('../middleware/auth');

// @route   POST api/auth/login
// @desc    Authenticate user & get token — accepts email OR studentCode
// @access  Public
router.post('/login', async (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
        return res.status(400).json({ message: 'Please enter all fields' });
    }

    try {
        // Allow login via Email OR StudentCode
        const [rows] = await pool.query(`
            SELECT u.ID, u.StudentCode, u.Name, u.Email, u.PasswordHash, u.RoleID, r.RoleName
            FROM Users u
            JOIN Roles r ON u.RoleID = r.ID
            WHERE u.Email = ? OR u.StudentCode = ?
        `, [email, email.toUpperCase()]);

        if (rows.length === 0) {
            return res.status(400).json({ message: 'Invalid credentials' });
        }

        const user = rows[0];
        const isMatch = await bcrypt.compare(password, user.PasswordHash);

        if (!isMatch) {
            return res.status(400).json({ message: 'Invalid credentials' });
        }

        const payload = {
            id: user.ID,
            email: user.Email,
            roleId: user.RoleID,
            role: user.RoleName
        };

        jwt.sign(
            payload,
            process.env.JWT_SECRET,
            { expiresIn: 3600 * 24 }, // 1 day
            (err, token) => {
                if (err) throw err;
                res.json({
                    token,
                    user: {
                        id: user.ID,
                        studentCode: user.StudentCode,
                        name: user.Name,
                        email: user.Email,
                        role: user.RoleName
                    }
                });
            }
        );
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// @route   GET api/auth/me
// @desc    Get user data
// @access  Private
router.get('/me', verifyToken, async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT u.ID, u.StudentCode, u.Name, u.Email, u.Phone, u.DateOfBirth, u.Gender, u.City, u.Country, u.CollegeName, r.RoleName
            FROM Users u
            JOIN Roles r ON u.RoleID = r.ID
            WHERE u.ID = ?
        `, [req.user.id]);

        if (rows.length === 0) {
            return res.status(404).json({ message: 'User not found' });
        }

        res.json(rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

const crypto = require('crypto');
const nodemailer = require('nodemailer');

// Handle email sending
const transporter = nodemailer.createTransport({
    // Using a fake/test SMTP or gmail for demonstration. 
    // In production, user should set these in .env
    host: process.env.SMTP_HOST || 'smtp.gmail.com',
    port: process.env.SMTP_PORT || 587,
    secure: false, // true for 465, false for other ports
    auth: {
        user: process.env.SMTP_USER || 'test@gmail.com', 
        pass: process.env.SMTP_PASS || 'password'
    }
});

// @route   POST api/auth/forgot-password
// @desc    Send password reset email
// @access  Public
router.post('/forgot-password', async (req, res) => {
    const { email } = req.body;
    if (!email) return res.status(400).json({ message: 'Email is required' });

    try {
        const [rows] = await pool.query(`SELECT ID, Name FROM Users WHERE Email = ?`, [email]);
        if (rows.length === 0) {
            // Return success even if not found to prevent email enumeration
            return res.json({ message: 'If that email exists, a reset link has been sent.' });
        }

        const user = rows[0];
        const resetToken = crypto.randomBytes(32).toString('hex');
        
        // Save token to DB, valid for 1 hour
        const expiry = new Date(Date.now() + 3600000); // 1 hour from now

        await pool.query(
            `UPDATE Users SET ResetToken = ?, ResetTokenExpiry = ? WHERE ID = ?`,
            [resetToken, expiry, user.ID]
        );

        // Link to frontend reset page
        // Format: http://localhost:5173/reset-password/TOKEN
        const resetLink = `${process.env.FRONTEND_URL || 'http://localhost:5173'}/reset-password/${resetToken}`;

        const mailOptions = {
            from: `"Creoed LMS" <${process.env.SMTP_USER || 'noreply@creoed.com'}>`,
            to: email,
            subject: 'Password Reset Request',
            html: `
                <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; border: 1px solid #e0e0e0; border-radius: 8px; overflow: hidden;">
                    <div style="background-color: #1aae64; padding: 24px; text-align: center;">
                        <h1 style="color: #ffffff; margin: 0; font-size: 24px;">Creoed LMS</h1>
                    </div>
                    <div style="padding: 32px 24px; background-color: #ffffff;">
                        <h2 style="color: #333333; margin-top: 0;">Password Reset</h2>
                        <p style="color: #555555; font-size: 16px; line-height: 1.5;">Hello ${user.Name},</p>
                        <p style="color: #555555; font-size: 16px; line-height: 1.5;">We received a request to reset your password. Click the button below to choose a new one:</p>
                        <div style="text-align: center; margin: 32px 0;">
                            <a href="${resetLink}" style="background-color: #1aae64; color: #ffffff; padding: 14px 28px; text-decoration: none; border-radius: 6px; font-weight: bold; display: inline-block;">Reset Password</a>
                        </div>
                        <p style="color: #555555; font-size: 14px; line-height: 1.5;">Or copy and paste this link into your browser:</p>
                        <p style="color: #0077cc; font-size: 14px; word-break: break-all;">${resetLink}</p>
                        <p style="color: #888888; font-size: 14px; margin-top: 32px;">If you didn't request this, you can safely ignore this email. The link will expire in 1 hour.</p>
                    </div>
                </div>
            `
        };

        // Don't await strictly if you don't want it to crash if SMTP isn't setup. Just log error on fail.
        transporter.sendMail(mailOptions).catch(err => console.error('Email error:', err));
        
        // Log the link in terminal for easy testing locally!
        console.log('RESET LINK:', resetLink);

        res.json({ message: 'If that email exists, a reset link has been sent.' });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// @route   POST api/auth/reset-password
// @desc    Reset password using token
// @access  Public
router.post('/reset-password', async (req, res) => {
    const { token, newPassword } = req.body;
    
    if (!token || !newPassword) return res.status(400).json({ message: 'Missing fields' });

    try {
        const [rows] = await pool.query(`
            SELECT ID, ResetTokenExpiry FROM Users WHERE ResetToken = ?
        `, [token]);

        if (rows.length === 0) {
            return res.status(400).json({ message: 'Invalid or expired token' });
        }

        const user = rows[0];
        if (new Date() > new Date(user.ResetTokenExpiry)) {
            return res.status(400).json({ message: 'Token has expired' });
        }

        const salt = await bcrypt.genSalt(10);
        const hash = await bcrypt.hash(newPassword, salt);

        await pool.query(`
            UPDATE Users SET PasswordHash = ?, ResetToken = NULL, ResetTokenExpiry = NULL WHERE ID = ?
        `, [hash, user.ID]);

        res.json({ message: 'Password has been reset successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

module.exports = router;

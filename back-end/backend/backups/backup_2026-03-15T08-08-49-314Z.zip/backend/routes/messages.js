const express = require('express');
const router = express.Router();
const { verifyToken } = require('../middleware/auth');
const { pool } = require('../config/db');

// @route   GET api/messages/contacts
// @desc    Get top tutors/students who exchange messages
// @access  Private
router.get('/contacts', verifyToken, async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT DISTINCT u.ID, u.Name, u.StudentCode, r.RoleName
            FROM Users u
            JOIN Roles r ON u.RoleID = r.ID
            WHERE u.ID IN (
                SELECT SenderID FROM Messages WHERE ReceiverID = ?
                UNION
                SELECT ReceiverID FROM Messages WHERE SenderID = ?
            )
        `, [req.user.id, req.user.id]);
        
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// @route   GET api/messages/thread/:userId
// @desc    Get messages with a specific user
// @access  Private
router.get('/thread/:userId', verifyToken, async (req, res) => {
    try {
        const [rows] = await pool.query(`
            SELECT m.*, u.Name as SenderName 
            FROM Messages m
            JOIN Users u ON m.SenderID = u.ID
            WHERE (m.SenderID = ? AND m.ReceiverID = ?)
               OR (m.SenderID = ? AND m.ReceiverID = ?)
            ORDER BY m.SentAt ASC
        `, [req.user.id, req.params.userId, req.params.userId, req.user.id]);

        // Mark as read
        await pool.query(`UPDATE Messages SET IsRead = TRUE WHERE SenderID = ? AND ReceiverID = ?`, 
            [req.params.userId, req.user.id]);

        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// @route   POST api/messages/:receiverId
// @desc    Send a DM
// @access  Private
router.post('/:receiverId', verifyToken, async (req, res) => {
    const { message } = req.body;
    if (!message) return res.status(400).json({ msg: 'Message is required' });

    try {
        await pool.query(
            `INSERT INTO Messages (SenderID, ReceiverID, Message) VALUES (?, ?, ?)`,
            [req.user.id, req.params.receiverId, message]
        );
        res.json({ success: true });
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

// @route   GET api/messages/users
// @desc    Get list of available people to chat with (Tutors/Students based on enrolled classes)
// @access  Private
router.get('/users', verifyToken, async (req, res) => {
    try {
        let query = '';
        let params = [req.user.id];

        if (req.user.role === 'Student') {
            // Students can chat with their Tutors
            query = `
                SELECT DISTINCT u.ID, u.Name, 'Tutor' as Type
                FROM Users u
                JOIN Classes c ON c.TutorID = u.ID
                JOIN ClassStudents cs ON cs.ClassID = c.ID
                WHERE cs.StudentID = ?
            `;
        } else if (req.user.role === 'Tutor') {
            // Tutors can chat with their Students
            query = `
                SELECT DISTINCT u.ID, u.Name, 'Student' as Type, u.StudentCode
                FROM Users u
                JOIN ClassStudents cs ON cs.StudentID = u.ID
                JOIN Classes c ON cs.ClassID = c.ID
                WHERE c.TutorID = ?
            `;
        } else {
            // Admins can see everyone
            query = `
                SELECT u.ID, u.Name, r.RoleName as Type, u.StudentCode
                FROM Users u
                JOIN Roles r ON u.RoleID = r.ID
                WHERE u.ID != ?
            `;
        }

        const [rows] = await pool.query(query, params);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).send('Server Error');
    }
});

module.exports = router;

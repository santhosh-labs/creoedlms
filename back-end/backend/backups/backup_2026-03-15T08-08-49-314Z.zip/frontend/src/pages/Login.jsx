import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../api';

export default function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const navigate = useNavigate();

    const [showForgot, setShowForgot] = useState(false);
    const [forgotEmail, setForgotEmail] = useState('');
    const [forgotLoading, setForgotLoading] = useState(false);
    const [forgotMessage, setForgotMessage] = useState({ type: '', text: '' });

    const handleLogin = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
            // Connects to /api/auth/login powered by backend DB
            const res = await api.post('/auth/login', { email, password });

            localStorage.setItem('user', JSON.stringify(res.data.user));
            localStorage.setItem('token', res.data.token);

            navigate('/');
        } catch (err) {
            if (err.response && err.response.data.message) {
                setError(err.response.data.message);
            } else {
                setError('Network Error. Please make sure the SQL Database Backend is running.');
            }
        } finally {
            setLoading(false);
        }
    };

    const handleForgot = async (e) => {
        e.preventDefault();
        setForgotLoading(true);
        setForgotMessage({ type: '', text: '' });
        try {
            const res = await api.post('/auth/forgot-password', { email: forgotEmail });
            setForgotMessage({ type: 'success', text: res.data.message });
        } catch (err) {
            setForgotMessage({ type: 'error', text: err.response?.data?.message || 'Failed to send reset link.' });
        } finally {
            setForgotLoading(false);
        }
    };

    return (
        <div className="auth-container">
            <div className="auth-card" style={{ position: 'relative' }}>
                <div className="auth-header">
                    <div className="logo-icon">C</div>
                    <h2>{showForgot ? 'Reset Password' : 'Sign in'}</h2>
                    <p className="subtitle">{showForgot ? 'Enter your email to receive a reset link' : 'Use your Email or Student ID (e.g. CR261234)'}</p>
                </div>

                {!showForgot ? (
                    <>
                        {error && (
                            <div style={{ padding: '12px', background: 'var(--danger-bg)', color: 'var(--danger)', borderRadius: '4px', marginBottom: '16px', fontSize: '13px' }}>
                                {error}
                            </div>
                        )}

                        <form onSubmit={handleLogin}>
                            <div className="form-group">
                                <input
                                    type="text"
                                    className="form-input"
                                    placeholder="Email or Student ID (e.g. CR261234)"
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                />
                            </div>
                            <div className="form-group">
                                <input
                                    type="password"
                                    className="form-input"
                                    placeholder="Enter your password"
                                    value={password}
                                    onChange={(e) => setPassword(e.target.value)}
                                    required
                                />
                            </div>

                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '32px' }}>
                                <button type="button" onClick={() => setShowForgot(true)} style={{ background: 'none', border: 'none', color: 'var(--primary)', fontWeight: '500', cursor: 'pointer', padding: 0 }}>Forgot password?</button>
                                <button type="submit" className="btn btn-primary" disabled={loading}>
                                    {loading ? 'Signing in...' : 'Sign in'}
                                </button>
                            </div>
                        </form>
                    </>
                ) : (
                    <form onSubmit={handleForgot}>
                        {forgotMessage.text && (
                            <div style={{ padding: '12px', background: forgotMessage.type === 'error' ? 'var(--danger-bg)' : '#e8f5ee', color: forgotMessage.type === 'error' ? 'var(--danger)' : 'var(--primary)', borderRadius: '4px', marginBottom: '16px', fontSize: '13px' }}>
                                {forgotMessage.text}
                            </div>
                        )}
                        <div className="form-group">
                            <input
                                type="email"
                                className="form-input"
                                placeholder="name@example.com"
                                value={forgotEmail}
                                onChange={(e) => setForgotEmail(e.target.value)}
                                required
                            />
                        </div>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '32px' }}>
                            <button type="button" onClick={() => { setShowForgot(false); setForgotMessage({type:'', text:''}); setForgotEmail(''); }} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', fontWeight: '500', cursor: 'pointer', padding: 0 }}>Back to login</button>
                            <button type="submit" className="btn btn-primary" disabled={forgotLoading}>
                                {forgotLoading ? 'Sending...' : 'Send Reset Link'}
                            </button>
                        </div>
                    </form>
                )}
            </div>
        </div>
    );
}

import { useEffect, useState, useRef } from 'react';
import { MessageCircle, Send, Search, User } from 'lucide-react';
import api from '../api';

export default function Messages({ user }) {
    const [contacts, setContacts] = useState([]);
    const [search, setSearch] = useState('');
    const [activeContact, setActiveContact] = useState(null);
    const [messages, setMessages] = useState([]);
    const [replyText, setReplyText] = useState('');
    const [loading, setLoading] = useState(false);
    const messagesEndRef = useRef(null);

    // Fetch available people to chat with (Tutors see their Students, Students see their Tutors)
    useEffect(() => {
        api.get('/messages/users')
           .then(r => setContacts(r.data))
           .catch(() => {});
    }, []);

    // Load conversation when clicking a contact
    useEffect(() => {
        if (!activeContact) return;
        setLoading(true);
        api.get(`/messages/thread/${activeContact.ID}`)
           .then(r => {
               setMessages(r.data);
               scrollToBottom();
           })
           .catch(() => {})
           .finally(() => setLoading(false));
           
        // Simple polling every 5 seconds for new messages in the active thread
        const interval = setInterval(() => {
            api.get(`/messages/thread/${activeContact.ID}`).then(r => setMessages(r.data)).catch(()=>{});
        }, 5000);
        return () => clearInterval(interval);
    }, [activeContact]);

    const scrollToBottom = () => {
        setTimeout(() => messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 100);
    };

    const sendMessage = async () => {
        if (!replyText.trim() || !activeContact) return;
        const text = replyText;
        setReplyText('');
        
        // Optimistic update
        setMessages(prev => [...prev, {
            ID: Date.now(),
            SenderID: user.id,
            Message: text,
            SentAt: new Date().toISOString()
        }]);
        scrollToBottom();

        try {
            await api.post(`/messages/${activeContact.ID}`, { message: text });
            // Re-fetch to get exact DB state
            const r = await api.get(`/messages/thread/${activeContact.ID}`);
            setMessages(r.data);
        } catch {
            alert('Failed to send message.');
        }
    };

    const filteredContacts = contacts.filter(c => c.Name.toLowerCase().includes(search.toLowerCase()) || (c.StudentCode && c.StudentCode.toLowerCase().includes(search.toLowerCase())));

    return (
        <div className="content-wrapper" style={{ height: 'calc(100vh - 84px)', paddingBottom: '0' }}>
            <div style={{ display: 'flex', height: '100%', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', overflow: 'hidden', background: 'var(--surface)' }}>
                
                {/* Left Sidebar - Contact List */}
                <div style={{ width: '320px', borderRight: '1px solid var(--border)', display: 'flex', flexDirection: 'column', background: 'var(--bg)' }}>
                    <div style={{ padding: '16px', borderBottom: '1px solid var(--border-light)' }}>
                        <h2 style={{ margin: '0 0 12px', fontSize: '18px', display: 'flex', alignItems: 'center', gap: '8px' }}>
                            <MessageCircle size={18} style={{ color: 'var(--primary)' }}/> Messages
                        </h2>
                        <div style={{ position: 'relative' }}>
                            <Search size={14} style={{ position: 'absolute', left: '10px', top: '10px', color: 'var(--text-muted)' }}/>
                            <input 
                                placeholder="Search by name or code..."
                                value={search}
                                onChange={e => setSearch(e.target.value)}
                                style={{ width: '100%', boxSizing: 'border-box', padding: '8px 10px 8px 32px', borderRadius: 'var(--radius-sm)', border: '1px solid var(--border)', fontSize: '13px' }}
                            />
                        </div>
                    </div>
                    
                    <div style={{ flex: 1, overflowY: 'auto' }}>
                        {contacts.length === 0 ? <div style={{ padding: '32px', textAlign: 'center', color: 'var(--text-muted)', fontSize: '13px' }}>No contacts available. You must be assigned to an active class.</div> :
                         filteredContacts.length === 0 ? <div style={{ padding: '20px', textAlign: 'center', color: 'var(--text-muted)', fontSize: '13px' }}>No matches found.</div> :
                         filteredContacts.map(c => (
                             <div key={c.ID} onClick={() => setActiveContact(c)} style={{ display: 'flex', alignItems: 'center', gap: '12px', padding: '14px 16px', cursor: 'pointer', borderBottom: '1px solid var(--border-light)', background: activeContact?.ID === c.ID ? '#e8f5ee' : 'transparent' }}>
                                 <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'var(--primary)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold' }}>
                                     {c.Name.charAt(0)}
                                 </div>
                                 <div style={{ flex: 1, overflow: 'hidden' }}>
                                     <div style={{ fontWeight: 600, fontSize: '14px', whiteSpace: 'nowrap', textOverflow: 'ellipsis', overflow: 'hidden', color: activeContact?.ID === c.ID ? 'var(--primary)' : 'var(--text-main)' }}>{c.Name}</div>
                                     <div style={{ fontSize: '11px', color: 'var(--text-muted)', marginTop: '2px' }}>
                                         {c.Type} {c.StudentCode && `• ${c.StudentCode}`}
                                     </div>
                                 </div>
                             </div>
                         ))}
                    </div>
                </div>

                {/* Right Area - Chat View */}
                <div style={{ flex: 1, display: 'flex', flexDirection: 'column', background: 'var(--surface)' }}>
                    {!activeContact ? (
                        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', color: 'var(--text-muted)' }}>
                            <div style={{ width: '64px', height: '64px', borderRadius: '50%', background: 'var(--bg)', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px' }}>
                                <MessageCircle size={32} style={{ color: 'var(--border)' }}/>
                            </div>
                            <h3 style={{ margin: 0, color: 'var(--text-main)' }}>Your Messages</h3>
                            <p style={{ margin: '8px 0 0', fontSize: '13px' }}>Select a student or tutor to start a direct chat.</p>
                        </div>
                    ) : (
                        <>
                            {/* Chat Header */}
                            <div style={{ padding: '16px 24px', borderBottom: '1px solid var(--border)', display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--bg)' }}>
                                <div style={{ width: '40px', height: '40px', borderRadius: '50%', background: 'var(--primary)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 'bold' }}>
                                    {activeContact.Name.charAt(0)}
                                </div>
                                <div>
                                    <h3 style={{ margin: 0, fontSize: '16px', fontWeight: 700 }}>{activeContact.Name}</h3>
                                    <span style={{ fontSize: '12px', color: 'var(--text-muted)' }}>{activeContact.Type} {activeContact.StudentCode && `• ${activeContact.StudentCode}`}</span>
                                </div>
                            </div>

                            {/* Messages Container */}
                            <div style={{ flex: 1, padding: '24px', overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: '16px' }}>
                                {loading && messages.length === 0 ? <div style={{ textAlign: 'center', color: 'var(--text-muted)' }}>Loading messages...</div> :
                                 messages.length === 0 ? <div style={{ textAlign: 'center', color: 'var(--text-muted)', margin: 'auto' }}>No messages yet. Say hello! 👋</div> :
                                 messages.map((m, i) => {
                                     const isMine = m.SenderID === user.id;
                                     const showTime = true; // Could group by time later
                                     return (
                                         <div key={m.ID} style={{ display: 'flex', flexDirection: 'column', alignItems: isMine ? 'flex-end' : 'flex-start' }}>
                                             <div style={{ 
                                                 maxWidth: '70%', 
                                                 padding: '12px 16px', 
                                                 borderRadius: isMine ? 'var(--radius-md) var(--radius-md) 2px var(--radius-md)' : 'var(--radius-md) var(--radius-md) var(--radius-md) 2px', 
                                                 background: isMine ? 'var(--primary)' : 'var(--bg)', 
                                                 color: isMine ? '#fff' : 'var(--text-main)', 
                                                 fontSize: '14px', 
                                                 lineHeight: '1.5',
                                                 border: isMine ? 'none' : '1px solid var(--border)'
                                             }}>
                                                 {m.Message}
                                             </div>
                                             {showTime && (
                                                <div style={{ fontSize: '10px', color: 'var(--text-muted)', marginTop: '4px', margin: isMine ? '0 4px 0 0' : '0 0 0 4px' }}>
                                                    {new Date(m.SentAt).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' })}
                                                </div>
                                             )}
                                         </div>
                                     );
                                })}
                                <div ref={messagesEndRef} />
                            </div>

                            {/* Input Area */}
                            <div style={{ padding: '16px 24px', borderTop: '1px solid var(--border)', background: 'var(--surface)' }}>
                                <div style={{ display: 'flex', gap: '12px', background: 'var(--bg)', border: '1px solid var(--border)', borderRadius: 'var(--radius-md)', padding: '6px' }}>
                                    <input 
                                        style={{ flex: 1, border: 'none', outline: 'none', padding: '8px 12px', fontSize: '14px', background: 'transparent', color: 'var(--text-main)' }} 
                                        placeholder="Type a message..." 
                                        value={replyText}
                                        onChange={e => setReplyText(e.target.value)}
                                        onKeyDown={e => { if(e.key === 'Enter') sendMessage() }}
                                    />
                                    <button 
                                        className="btn btn-primary" 
                                        onClick={sendMessage} 
                                        disabled={!replyText.trim()}
                                        style={{ borderRadius: 'var(--radius-sm)', padding: '8px 16px', display: 'flex', alignItems: 'center', justifyContent: 'center' }}
                                    >
                                        <Send size={16} />
                                    </button>
                                </div>
                            </div>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
}
